# Buraya kendi parser kodunu koyacaksın
print('Parser çalıştı')
